import boto3
from botocore.config import Config
import pandas as pd
import numpy as np
import io
import logging
from botocore.exceptions import ClientError
import os
import re
import json
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import urllib
from urllib.parse import unquote_plus
import time
import uuid
import hashlib

# =====================================================================================
# CONFIGURACIÓN GLOBAL
# =====================================================================================
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.info("🚀 LAMBDA STARTING - v8.0 FINAL ENGINE WITH TIMESTAMP RENAME")

s3_client = boto3.client('s3')
sns_client = boto3.client('sns')

ARCHIVO_TABLA_MAP = {
    "CLIENTES_POR_PRODUCTO": "007_ENT_CLIENTES_PRODUCTO",
    "FILE_CAPTACION": "110_ENT_CAPTACION",
    "RECO": "106_RECO",
    "ENT_CAJA_CAPTACION": "109_ENT_CAJA_CAPTACION",
    "FILE_SISPAGOS": "105_SISPAGOS_IO",
    "FT_TPA": "102_ENT_TASAS_PASIVAS"
}

# =====================================================================================
# CONFIGURACIÓN DE TABLAS
# =====================================================================================
def get_table_configurations():
    """
    Contiene el "expediente" con las reglas para cada tabla.
    """
    configs = {
        "110_ENT_CAPTACION": {
            'columns': ['ID', 'NUM_ID_OP', 'INSTRUMENTO', 'SALDO_PRINCIPAL', 'SALDO_INTERES_DEV', 'MONEDA', 'FEC_VEN_CAPITAL', 'FEC_VEN_INTERES', 'SALDO_PROMEDIO_MEN', 'INTERES_DEV_MES', 'ESCUENTA_ACTIVA', 'ESCUENTA_CERRADA_MES', 'PERSONALIDAD_JURIDICA', 'NUMERO_CUENTA', 'CODIGO_CLIENTE', 'OFICINA', 'CONTRAPARTE', 'ESFRANJAFRONTERIZA', 'SALDO_TOTAL', 'COSTO', 'SALDO_PRINCIPAL_VAL', 'SALDO_INTERES_DEV_VAL', 'SALDO_PROMEDIO_MEN_VAL', 'INTERES_DEV_MES_VAL', 'SALDO_TOTAL_VAL', 'SALDO_TOTAL_VAL_USD', 'SALDO_PRINCIPAL_VAL_USD', 'SALDO_INTERES_DEV_VAL_USD', 'SALDO_PROMEDIO_MEN_VAL_USD', 'INTERES_DEV_MES_VAL_USD', 'PLAZO_VENC_CAPITAL', 'PLAZO_VENC_INTERES', 'TIPO_PLAZO_VENC_CAPITAL', 'TIPO_PLAZO_VENC_INTERES', 'TIPO_SALDO', 'ESCUENTA_ABIERTA_MES', 'RANGO_INVERSION', 'TIPO_MONEDA', 'FECHA_EXTRACCION'],
            'date_fields': ['FEC_VEN_CAPITAL', 'FEC_VEN_INTERES'],
            'non_nullable_defaults': {'ESFRANJAFRONTERIZA': 'N', 'CONTRAPARTE': 'N/A'}
        },
        "007_ENT_CLIENTES_PRODUCTO": {
            'columns': ['ID', 'PRODUCTO', 'MUNICIPIO', 'TIPO_CLIENTE', 'PERSONALIDAD_JURIDICA', 'CODIGO_CLIENTE', 'MONEDA', 'TIPO_INSTRUMENTO', 'MONTO_OPERACIONES', 'NUMERO_OPERACIONES', 'FECHA_INFO', 'FECHA_EXTRACCION'],
            'date_fields': ['FECHA_INFO'],
            'non_nullable_defaults': {}
        },
        "106_RECO": {
            'columns': ['ID', 'CODIGO_PRODUCTO', 'TIPO_INSTRUMENTO', 'PERIODICIDAD_COBRO','OPERACIONLIBRE', 'MONEDA', 'MONTO_FIJO', 'MONTO_VAR','BASE_COBRO', 'LIMITE_MAX', 'TIPO_MOVIMIENTO', 'COMENTARIO','FECHA_EXTRACCION'],
            'date_fields': [],
            'non_nullable_defaults': {}
        },
        "109_ENT_CAJA_CAPTACION": {
            'columns': ['ID', 'FECHA', 'CONCEPTO', 'MONTO_MN', 'MONTO_MER', 'MONTO_MEA', 'MONEDA', 'FECHA_EXTRACCION'],
            'date_fields': ['FECHA'],
            'non_nullable_defaults': {'MONTO_MN': 0, 'MONTO_MER': 0, 'MONTO_MEA': 0}
        },
        "105_SISPAGOS_IO": {
            'column_map': {'Año': 'AÑO', 'Mes': 'MES', 'Seccion': 'SECCION', 'Moneda': 'MONEDA','Tipo de Cuenta': 'TIPO_DE_CUENTA', 'Tipo de Persona': 'TIPO_DE_PERSONA','Numero de Cuentas': 'NUMERO_DE_CUENTAS', 'Saldo Promedio de las cuentas': 'SALDO_PROMEDIO_DE_LAS_CUENTAS','FECHA_REPORTE': 'FECHA_REPORTE'},
            'columns': ['ID', 'AÑO', 'MES', 'SECCION', 'MONEDA', 'TIPO_DE_CUENTA', 'TIPO_DE_PERSONA', 'NUMERO_DE_CUENTAS', 'SALDO_PROMEDIO_DE_LAS_CUENTAS', 'FECHA_REPORTE', 'FECHA_EXTRACCION'],
            'date_fields': ['FECHA_REPORTE'],
            'non_nullable_defaults': {'AÑO': 0, 'MES': 0, 'NUMERO_DE_CUENTAS': 0, 'SALDO_PROMEDIO_DE_LAS_CUENTAS': 0, 'FECHA_REPORTE': '1900-01-01'}
        },
        "102_ENT_TASAS_PASIVAS": {
            'preprocess_steps': {'PLAZO1': 'extract_numbers','PLAZO2': 'extract_numbers'},
            'columns': ['ID', 'CVECTA', 'PLAZO1', 'PLAZO2', 'IMPLIM1', 'IMPLIM2', 'TASA', 'FORTASA', 'TASAR', 'PUNTOS', 'FACTOR', 'FECHA', 'FECHA_EXTRACCION'],
            'date_fields': ['FECHA'],
            'non_nullable_defaults': {'IMPLIM1': 0.0, 'IMPLIM2': 0.0, 'TASA': 0, 'PUNTOS': 0, 'FACTOR': 0}
        }
    }
    return configs

# =====================================================================================
# MÓDULO DE LOGS DE PROCESAMIENTO
# =====================================================================================
def log_archivo_procesado(nombre_archivo, tabla_destino, estado, detalle_error, conn):
    try:
        query = text("""
            INSERT INTO RR.LogProcesadosLambda 
            (ID, NOMBRE_ARCHIVO, TABLA_DESTINO, FECHA_PROCESO, ESTADO, DETALLE_ERROR) 
            VALUES (NEWID(), :nombre_archivo, :tabla_destino, GETDATE(), :estado, :detalle_error)
        """)
        conn.execute(query, {
            "nombre_archivo": nombre_archivo,
            "tabla_destino": tabla_destino,
            "estado": estado,
            "detalle_error": detalle_error
        })
        logger.info(f"📝 Log de procesamiento registrado: {nombre_archivo} -> {estado}")
    except Exception as e:
        logger.error(f"❌ Error al registrar log de procesamiento: {e}")

# =====================================================================================
# MÓDULO DE CALIDAD DE DATOS
# =====================================================================================

def enviar_alerta_sns(mensaje, archivo):
    try:
        sns_client.publish(
            TopicArn="arn:aws:sns:us-west-2:304783584950:FileReplication_File_SQL_ERRORS",
            Subject=f"⚠️ Alerta en archivo: {archivo}",
            Message=mensaje
        )
        logger.info("📨 Notificación SNS enviada exitosamente")
    except Exception as sns_error:
        logger.error(f"❌ No se pudo enviar notificación SNS: {sns_error}")

def analyze_data_quality(original_df, cleaned_df, file_name):
    logger.info("🔬 Analizando calidad de datos...")
    report = {
        'total_registros': len(original_df),
        'registros_con_problemas': 0,
        'correcciones_aplicadas': {}
    }

    original_aligned = original_df.copy()
    original_aligned.columns = [re.sub(r'[^a-zA-Z0-9_]', '_', col) for col in original_aligned.columns]
    original_aligned = original_aligned.apply(pd.to_numeric, errors='ignore')

    common_cols = original_aligned.columns.intersection(cleaned_df.columns)
    comparison_df = original_aligned[common_cols].ne(cleaned_df[common_cols])

    if comparison_df.any(axis=None):
        corrections_count = comparison_df.sum()
        for col, count in corrections_count.items():
            if count > 0:
                report['correcciones_aplicadas'][col] = int(count)
        report['registros_con_problemas'] = int(comparison_df.any(axis=1).sum())

        mensaje = (
            f"Se detectaron {report['registros_con_problemas']} registros con problemas en el archivo {file_name}. "
            f"Correcciones aplicadas: {json.dumps(report['correcciones_aplicadas'])}"
        )
        enviar_alerta_sns(mensaje, file_name)
        logger.warning("🚨 Calidad de datos deficiente. Se disparó alerta SNS.")
    else:
        logger.info("✅ No se encontraron problemas de calidad de datos.")

    return report

def log_quality_report(quality_report, source_key, bucket, conn):
    file_name = os.path.basename(source_key)
    report_summary = {
        'archivo': file_name,
        'fecha_procesamiento': time.strftime('%Y-%m-%d %H:%M:%S'),
        **quality_report
    }

    try:
        report_key = f"RR_Data_Quality_Reports/DQ_Report_{file_name}_{time.strftime('%Y%m%d_%H%M%S')}.json"
        s3_client.put_object(
            Bucket=bucket,
            Key=report_key,
            Body=json.dumps(report_summary, indent=2),
            ContentType='application/json'
        )
        logger.info(f"📄 Reporte de calidad guardado en S3: {report_key}")
    except Exception as e:
        logger.error(f"❌ No se pudo guardar el reporte de calidad en S3: {e}")

    try:
        query = text("""
            INSERT INTO RR.LOG_CALIDAD_DATOS_LAMBDA (
                NOMBRE_ARCHIVO, BUCKET, FECHA_PROCESAMIENTO,
                TOTAL_REGISTROS, REGISTROS_VALIDOS, REGISTROS_INVALIDOS,
                PORCENTAJE_CALIDAD, ERRORES_DETECTADOS
            ) 
            VALUES (
                :nombre, :bucket, GETDATE(),
                :total, :validos, :invalidos,
                :porcentaje, :errores
            )
        """)
        total = quality_report.get('total_registros', 0)
        invalidos = quality_report.get('registros_con_problemas', 0)
        validos = total - invalidos
        porcentaje = (validos / total * 100) if total > 0 else 100

        conn.execute(query, {
            "nombre": source_key,
            "bucket": bucket,
            "total": total,
            "validos": validos,
            "invalidos": invalidos,
            "porcentaje": porcentaje,
            "errores": json.dumps(quality_report.get('correcciones_aplicadas', {}))
        })
        logger.info(f"📝 Resumen de calidad registrado en la base de datos.")
    except Exception as e:
        logger.error(f"❌ No se pudo registrar el resumen de calidad en la BD: {e}")

        # En tu código donde se analiza la calidad
    quality_report = analyze_data_quality(original_df, cleaned_df)
    notify_quality_issues(quality_report, file_name)  # <- NUEVO

# =====================================================================================
# MOTOR DE PROCESAMIENTO
# =====================================================================================
def dynamic_data_processor(df, mapped_table, db_config, source_key, bucket):
    all_configs = get_table_configurations()
    table_config = all_configs.get(mapped_table, {})
    params = urllib.parse.quote_plus(f"DRIVER={{{db_config['sql_driver']}}};SERVER={db_config['sql_server']};DATABASE={db_config['sql_database']};UID={db_config['sql_username']};PWD={db_config['sql_password']};TrustServerCertificate=yes")
    engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}", pool_pre_ping=True)
    with engine.begin() as conn:
        try:
            original_df = df.copy()
            df_processed = df.copy()
            preprocess_steps = table_config.get('preprocess_steps', {})
            for col, step in preprocess_steps.items():
                if col in df_processed.columns:
                    if step == 'extract_numbers':
                        df_processed[col] = df_processed[col].str.extract(r'(\d+)').astype(float).fillna(0)
                        logger.info(f"Paso de pre-procesamiento 'extract_numbers' aplicado a la columna '{col}'.")
            df_processed.columns = [re.sub(r'[^a-zA-Z0-9_]', '_', col) for col in df_processed.columns]
            df_processed = df_processed.apply(pd.to_numeric, errors='ignore')
            numeric_cols = df_processed.select_dtypes(include=np.number).columns
            df_processed[numeric_cols] = df_processed[numeric_cols].fillna(0)
            for col in table_config.get('date_fields', []):
                if col in df_processed.columns:
                    df_processed[col] = pd.to_datetime(df_processed[col], errors='coerce').dt.date
            for col, default in table_config.get('non_nullable_defaults', {}).items():
                if col in df_processed.columns:
                    df_processed[col] = df_processed[col].fillna(default)
                else:
                    df_processed[col] = default
            quality_report = analyze_data_quality(original_df, df_processed.copy(), os.path.basename(source_key))
            if quality_report['registros_con_problemas'] > 0:
                log_quality_report(quality_report, source_key, bucket, conn)
            df_processed['ID'] = [str(uuid.uuid4()) for _ in range(len(df_processed))]
            df_processed['FECHA_EXTRACCION'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
            final_columns = table_config.get('columns', [])
            for col in final_columns:
                if col not in df_processed.columns:
                    df_processed[col] = None
            df_to_insert = df_processed[[col for col in final_columns if col in df_processed.columns]]
            if not df_to_insert.empty:
                df_to_insert.to_sql(mapped_table, conn, schema='RR', if_exists='append', index=False)
                logger.info(f"✅ Datos insertados en RR.{mapped_table}")
                log_archivo_procesado(os.path.basename(source_key), mapped_table, "SUCCESS", None, conn)
                return True
            else:
                logger.warning("No hay datos válidos para insertar.")
                log_archivo_procesado(os.path.basename(source_key), mapped_table, "FAILED", "No hay datos válidos para insertar", conn)
                return False
        except Exception as e:
            logger.error(f"❌ Error en el motor de procesamiento para tabla {mapped_table}: {e}", exc_info=True)
            log_archivo_procesado(os.path.basename(source_key), mapped_table, "FAILED", str(e)[:1000], conn)
            return False

# =====================================================================================
# FUNCIONES DE ARRANQUE Y ORQUESTACIÓN
# =====================================================================================
def get_secret():
    secret_name = os.environ.get("SECRET_NAME", "arn:aws:secretsmanager:us-west-2:304783584950:secret:sqlservercredentials-pXnoMh")
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager')
    try:
        return json.loads(client.get_secret_value(SecretId=secret_name)['SecretString'])
    except Exception as e:
        logger.error(f"Error al recuperar secret: {e}")
        raise

def get_db_config():
    db_creds = get_secret()
    return {"sql_server": os.environ["SQL_SERVER"], "sql_database": os.environ["SQL_DATABASE"], "sql_username": db_creds['SQL_USERNAME'], "sql_password": db_creds['SQL_PASSWORD'], "sql_driver": os.environ["SQL_DRIVER"]}

def get_s3_info(event):
    try:
        if 'Records' in event and event['Records'] and 's3' in event['Records'][0]:
            s3_info = event['Records'][0]['s3']
            bucket = s3_info['bucket']['name']
            key = unquote_plus(s3_info['object']['key'])
            return bucket, key
    except Exception:
        return None, None

# =====================================================================================
# HANDLER PRINCIPAL CON SNS CONSOLIDADO Y NOTIFICACIÓN DE CALIDAD
# =====================================================================================
def lambda_handler(event, context):
    logger.info(f"--- HANDLER START: {context.aws_request_id} ---")
    if 'Records' not in event or not event['Records']:
        return {'statusCode': 200, 'body': 'Event has no records.'}

    db_config = get_db_config()
    all_configs = get_table_configurations()
    notificador = ErrorNotifier()
    results = []

    for record in event['Records']:
        bucket, source_key = get_s3_info({'Records': [record]})
        if not bucket: continue

        file_name = os.path.basename(source_key)
        mapped_table = None

        try:
            best_match_key = max((f for f in ARCHIVO_TABLA_MAP if f.lower() in file_name.lower()), key=len, default=None)
            if not best_match_key:
                results.append({'file': file_name, 'status': 'unconfigured'})
                try:
                    params = urllib.parse.quote_plus(f"DRIVER={{{db_config['sql_driver']}}};SERVER={db_config['sql_server']};DATABASE={db_config['sql_database']};UID={db_config['sql_username']};PWD={db_config['sql_password']};TrustServerCertificate=yes")
                    engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}", pool_pre_ping=True)
                    with engine.begin() as conn:
                        log_archivo_procesado(file_name, "UNKNOWN", "ERROR", "Archivo no configurado en ARCHIVO_TABLA_MAP", conn)
                except:
                    pass
                continue

            mapped_table = ARCHIVO_TABLA_MAP[best_match_key]
            table_config = all_configs.get(mapped_table, {})

            obj = s3_client.get_object(Bucket=bucket, Key=source_key)
            df = pd.read_csv(io.BytesIO(obj['Body'].read()), delimiter='|', encoding='utf-8', dtype=str)
            # raise RuntimeError("Forzando error para prueba de SNS")  # solo para test

            column_map = table_config.get('column_map')
            if column_map:
                df.rename(columns=column_map, inplace=True)
                logger.info(f"Mapeo de columnas aplicado para {file_name}")

            if dynamic_data_processor(df, mapped_table, db_config, source_key, bucket):
                results.append({'file': file_name, 'status': 'success'})

                # --- Mover y renombrar archivo procesado ---
                source_folder = os.path.dirname(source_key)
                destination_folder = os.path.join(source_folder, 'Procesados')
                timestamp = time.strftime('%Y-%m-%d')
                new_file_name = f"{timestamp}_{file_name}"
                destination_key = os.path.join(destination_folder, new_file_name)
                copy_source = {'Bucket': bucket, 'Key': source_key}
                s3_client.copy_object(CopySource=copy_source, Bucket=bucket, Key=destination_key)
                s3_client.delete_object(Bucket=bucket, Key=source_key)
                logger.info(f"✅ Archivo movido y renombrado exitosamente a: {destination_key}")
            else:
                results.append({'file': file_name, 'status': 'failed'})

        except Exception as e:
            logger.error(f"🚨 ERROR CRÍTICO procesando {file_name}: {e}", exc_info=True)
            # En vez de enviar SNS directamente:
            notificador.agregar_error(file_name, mensaje_calidad)


            try:
                params = urllib.parse.quote_plus(f"DRIVER={{{db_config['sql_driver']}}};SERVER={db_config['sql_server']};DATABASE={db_config['sql_database']};UID={db_config['sql_username']};PWD={db_config['sql_password']};TrustServerCertificate=yes")
                engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}", pool_pre_ping=True)
                with engine.begin() as conn:
                    log_archivo_procesado(file_name, mapped_table if mapped_table else 'UNKNOWN', "ERROR", str(e)[:1000], conn)
            except Exception as db_log_error:
                logger.error(f"❌ Error al registrar log en BD: {db_log_error}")

            results.append({'file': file_name, 'status': 'critical_error'})
            notificador.agregar_error(file_name, str(e))
            
# =====================================================================================
# MÓDULO DE ALERTAS SNS CONSOLIDADAS
# =====================================================================================

class ErrorNotifier:
    def __init__(self):
        self.errores_detectados = []

    def agregar_error(self, archivo, error):
        self.errores_detectados.append({"archivo": archivo, "error": str(error)})

    def enviar_alerta_final(self):
        if not self.errores_detectados:
            return

        resumen = "\n".join([
            f"📁 {e['archivo']}\n   ❌ Error: {e['error']}" for e in self.errores_detectados
        ])
        mensaje = (
            f"🚨 Se detectaron errores en los siguientes archivos:\n\n"
            f"{resumen}\n\n🕒 Fecha: {time.strftime('%Y-%m-%d %H:%M:%S')}"
        )

        try:
            sns_client.publish(
                TopicArn="arn:aws:sns:us-west-2:304783584950:FileReplication_File_SQL_ERRORS",
                Subject="📢 Resumen de errores en procesamiento de archivos",
                Message=mensaje
            )
            logger.info("📨 Notificación SNS consolidada enviada exitosamente")
        except Exception as sns_error:
            logger.error(f"❌ No se pudo enviar notificación consolidada SNS: {sns_error}")
